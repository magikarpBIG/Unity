﻿using UnityEngine;
using System.Collections;

public class GemStone : MonoBehaviour {
    public float xOffset = -5.0f;
    public float yOffset = -2.0f;
    public int rowIndex = 0;//行
    public int columnIndex = 0;//列

    public GameObject[] gemstoneBgs; //宝石的数组
    public int gemstoneType; //宝石的类型
    public GameControl gameController;
    public SpriteRenderer spriteRenderer;
    public bool isSelected {
        set {
            if (value)
            {
                spriteRenderer.color = Color.red; 
            }
            else {
                spriteRenderer.color = Color.white;
            }
        }
    }

    private GameObject gemstoneBg;



    // Use this for initialization
    void Awake() {
       
    }

    void Start() {
        gameController = GameObject.Find("GameControl").GetComponent<GameControl>();
        spriteRenderer = gemstoneBg.GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update() {

    }
    public void UpdatePosition(int _rowIndex,int _columnIndex) {  //调整宝石的位置
        rowIndex = _rowIndex;
        columnIndex = _columnIndex;
        this.transform.position = new Vector3(columnIndex*1.2f + xOffset,rowIndex*1.2f + yOffset, 0);

    }
    public void TweenToPostion(int _rowIndex, int _columnIndex) {
        rowIndex = _rowIndex;
        columnIndex = _columnIndex;
        iTween.MoveTo(this.gameObject,iTween.Hash("x",columnIndex * 1.2f+ xOffset,"y",rowIndex*1.2f +yOffset,"time",0.5f) );
    }

    public void RandomCreateGemstoneBg() { //生成随机宝石类型
        if (gemstoneBg != null)
            return;
        gemstoneType = Random.Range(0, gemstoneBgs.Length);
        gemstoneBg = Instantiate(gemstoneBgs[gemstoneType]) as GameObject;
        gemstoneBg.transform.parent = this.transform;

    }
    public void OnMouseDown() {
        gameController.Select(this);
    }
    public void Dispose() {
        Destroy(this.gameObject);
        Destroy(gemstoneBg.gameObject);
        gameController = null;
    }
 }
