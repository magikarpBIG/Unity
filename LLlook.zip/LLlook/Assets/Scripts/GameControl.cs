﻿using UnityEngine;
using System.Collections;

public class GameControl : MonoBehaviour {
    public GemStone gemstone;
    public int rowNum=7;//行数
    public int columNum = 10; //列数
    public ArrayList gemstoneList;

    public AudioClip match3Clip;
    public AudioClip swapClip;
    public AudioClip errorClip;


    private GemStone currentGemstone; //保存当前点击的宝石
    private ArrayList matchesGemstone;

	// Use this for initialization
	void Start () {
        gemstoneList = new ArrayList();
        matchesGemstone = new ArrayList();

        for (int rowIndex = 0; rowIndex < rowNum; rowIndex++) {
            ArrayList temp = new ArrayList();
            for (int columnIndex=0; columnIndex < columNum; columnIndex++)
            {
                GemStone c = AddGemstone(rowIndex, columnIndex); 
                temp.Add (c);
                
                 
                
            }
            gemstoneList.Add(temp);
        }
        if (CheckHorizontalMatches() || CheckVerticalMatches())
        {
            RemoveMatches();
        }

    }
	
	public GemStone AddGemstone(int rowIndex, int columnIndex) {
        GemStone c = Instantiate(gemstone) as GemStone;
        c.transform.parent = this.transform;
        c.GetComponent<GemStone>().RandomCreateGemstoneBg();
        c.GetComponent<GemStone>().UpdatePosition(rowIndex, columnIndex);
        return c;
    }
	
	// Update is called once per frame
	void Update () {
	
	}
    public void Select(GemStone c) {
        if (currentGemstone == null)
        {
            currentGemstone = c;
            currentGemstone.isSelected = true;
            return;
        }
        else {
            if (Mathf.Abs(currentGemstone.rowIndex - c.rowIndex) + Mathf.Abs(currentGemstone.columnIndex - c.columnIndex) == 1)
            {

                StartCoroutine(ExangeAndMatchches(currentGemstone, c));
            }
            else {
                audio.PlayOneShot(errorClip);
            }

            
            currentGemstone.isSelected = false;
            currentGemstone = null;
        }

    }
    IEnumerator ExangeAndMatchches(GemStone c1,GemStone c2) //实现交换并检测是否有相同的
    {
        Exchange(c1, c2);
        yield return new WaitForSeconds(0.5f);
        if (CheckHorizontalMatches() || CheckVerticalMatches())
        {

            RemoveMatches();
        }
        else {
            Debug.Log("2333");
            Exchange(c1,c2);
        }
    }
    bool CheckHorizontalMatches() { //检测水平方向
        bool isMatches = false;
        for (int rowIndex = 0; rowIndex < rowNum; rowIndex++) {
            
            for (int columnIndex = 0; columnIndex < columNum - 2; columnIndex++) {
                
                if ((GetGemStone(rowIndex,columnIndex).gemstoneType== GetGemStone(rowIndex, columnIndex+ 1).gemstoneType ) && (GetGemStone(rowIndex, columnIndex).gemstoneType == GetGemStone(rowIndex, columnIndex + 2).gemstoneType)){
                    Debug.Log("行消消乐");
                    AddMatches(GetGemStone(rowIndex, columnIndex));
                    AddMatches(GetGemStone(rowIndex, columnIndex + 1));
                    AddMatches(GetGemStone(rowIndex, columnIndex + 2));
                    isMatches = true;
                }
            }
        }
        return isMatches;
    }

    bool CheckVerticalMatches() {       //检测垂直方向
        bool isMatches = false;
        for (int columnIndex = 0; columnIndex < columNum; columnIndex++) {
            for (int rowIndex = 0; rowIndex < rowNum -2; rowIndex++) {
                if ((GetGemStone(rowIndex,columnIndex).gemstoneType == GetGemStone(rowIndex +1,columnIndex).gemstoneType)&& (GetGemStone(rowIndex , columnIndex).gemstoneType == GetGemStone(rowIndex + 2,columnIndex).gemstoneType)) {
                    Debug.Log("列十三点");
                    AddMatches(GetGemStone(rowIndex, columnIndex));
                    AddMatches(GetGemStone(rowIndex+ 1, columnIndex ));
                    AddMatches(GetGemStone(rowIndex+ 2, columnIndex ));
                    isMatches = true;
                }
            }
        }
        return isMatches;
    }

    void AddMatches(GemStone c) {
        if (matchesGemstone == null) {
            matchesGemstone = new ArrayList();}
            int index = matchesGemstone.IndexOf(c);//检测该宝石是否已在数组当中
            if (index == -1) {
                matchesGemstone.Add(c);
            }
      
    }

    void RemoveMatches() { //删除匹配的宝石
        for (int i = 0; i < matchesGemstone.Count; i++) {
            GemStone c = matchesGemstone[i] as GemStone; //读取宝石
            RemoveGemstone(c);
        }
        matchesGemstone = new ArrayList();
        StartCoroutine(WaitForCheckMatchesAgain()); //再次检测

    }
    IEnumerator WaitForCheckMatchesAgain() {  //再次消除协程
        yield return new WaitForSeconds(0.5f);
        if (CheckHorizontalMatches() || CheckVerticalMatches()) {
            RemoveMatches();
        }

    }

    void RemoveGemstone(GemStone c) { //实现删除功能
        //Debug.Log("shancbb");
        c.Dispose();
        audio.PlayOneShot(match3Clip);
        for (int i = c.rowIndex + 1; i < rowNum; i++) {
            GemStone tempGemstone = GetGemStone(i, c.columnIndex);
            tempGemstone.rowIndex--;
            SetGemStone(tempGemstone.rowIndex, tempGemstone.columnIndex, tempGemstone);
            //tempGemstone.UpdatePosition(tempGemstone.rowIndex, tempGemstone.columnIndex);
            tempGemstone.TweenToPostion(tempGemstone.rowIndex, tempGemstone.columnIndex);
        }
        GemStone newGemstone = AddGemstone(rowNum, c.columnIndex);
        newGemstone.rowIndex--;
        SetGemStone(newGemstone.rowIndex,newGemstone.columnIndex,newGemstone);
        //newGemstone.UpdatePosition(newGemstone.rowIndex, newGemstone.columnIndex);
        newGemstone.TweenToPostion(newGemstone.rowIndex, newGemstone.columnIndex);
    }
    public GemStone GetGemStone(int rowIndex, int columnIndex) { //通过行号和列号 取得所对应位置的宝石
        ArrayList temp = gemstoneList[rowIndex] as ArrayList;
        GemStone c = temp[columnIndex] as GemStone;
        return c;
    }

    public void SetGemStone(int rowIndex, int columnIndex, GemStone c) { //设备所对应列好和列号位置的宝石
        ArrayList temp = gemstoneList[rowIndex]as ArrayList;
        temp[columnIndex] = c;
    }

    public void Exchange(GemStone c1,GemStone c2) {  //实现宝石之间的位置交换
        audio.PlayOneShot(swapClip);
        SetGemStone(c1.rowIndex,c1.columnIndex, c2);
        SetGemStone(c2.rowIndex, c2.columnIndex, c1);

        //交换从c1c2的行号
        int tempRowIndex;
        tempRowIndex = c1.rowIndex;
        c1.rowIndex = c2.rowIndex;
        c2.rowIndex = tempRowIndex;

        //交换c1c2的列好
        int tempColumnIndex;
        tempColumnIndex = c1.columnIndex;
        c1.columnIndex = c2.columnIndex;
        c2.columnIndex = tempColumnIndex;

        //c1.UpdatePosition(c1.rowIndex, c1.columnIndex);
        //c2.UpdatePosition(c2.rowIndex, c2.columnIndex);
        c1.TweenToPostion(c1.rowIndex, c1.columnIndex);
        c2.TweenToPostion(c2.rowIndex, c2.columnIndex);

    }

}