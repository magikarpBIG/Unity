﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zhuzisc : MonoBehaviour {
    private float Ymove;
    public Transform zhuzizi;

    private Transform m_transform;

    //生成时间间隔
    public float m_timer=2;
	// Use this for initialization
	void Start () {
		m_transform=this.GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
        Ymove = Random.Range(-3,2);
        m_timer -= Time.deltaTime;
        if (m_timer <= 0)
        {
            Instantiate(zhuzizi,new Vector3(m_transform.position.x,m_transform.position.y+Ymove,m_transform.position.z),m_transform.rotation);
            m_timer = 2;
        }
	}
}
