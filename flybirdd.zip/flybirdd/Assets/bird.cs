﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bird : MonoBehaviour {
    public Rigidbody m_rigidbody;
    public float power=5;
    public SpriteRenderer m_sprite;
    public Sprite[] texture;
    public float timerr=0;
    public float timerr2= 0;

    public GameObject penzhuang;
 	// Use this for initialization
	void Start () {
        m_rigidbody = this.GetComponent<Rigidbody>();
        m_sprite = this.GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
        timerr++;
        timerr2 = 20;
        
        if(Input.GetMouseButtonDown(0))
       {
          
           m_rigidbody.velocity = new Vector3(0, power * Time.deltaTime,0);
           
           
       }
        if (timerr % timerr2 >= 0 && timerr % timerr2 < 10)
        {
            m_sprite.sprite = texture[0];
        }
        else if(timerr % timerr2 >=10 && timerr % timerr2 <= 19)
        {
            m_sprite.sprite = texture[1];
        }


         
	}
    void OnTriggerEnter(Collider other)
    { 
        if(other.gameObject!=penzhuang)
        {
            Debug.Log("66336"); ;
        }
    }
}
