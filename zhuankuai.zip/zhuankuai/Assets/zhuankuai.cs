﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zhuankuai : MonoBehaviour {

    public float hang=5;
    public float lie=7;

    public GameObject gobj;
    //public Transform posdian;

    //public float Xjuli=0;
  //  public float Yjuli=0;

    //public zkk zk;

    
	// Use this for initialization
    void Start()
    {

       // posdian = this.gameObject.transform;
           kkas();
      
    }
	// Update is called once per frame
	void Update () {
        
	}
    void kkas()
    { 
     for (int i = 0;i < hang;  i++)
        {
            
            
       
              
            for (int x = 0; x < lie;x++ )
            {  
                                                                 
                //this.transform.position = new Vector3(0, -lie + Xjuli * 0.5f,0);                
                Instantiate(gobj,transform.position+new Vector3(0,i*-0.5f,x*-1.5f),transform.rotation);
               // gobj.transform.parent = this.transform;
          
                  
            } 
        }
    }

    /*void mapp()
    { 
      for (int row = 0; row < hang; row++)
        {
            ArrayList temp = new ArrayList();
            for (int col = 0; col < lie; col++)
            {
                zkk c = Instantiate(zk) as zkk;
                c.transform.parent = this.transform;

                c.GetComponent<zkk>().UpdatePosition(row, col);
                // c.GetComponent<zkk>().UpdatePosition(rowlizi, columlizi);

            }

        }*/
    
}
