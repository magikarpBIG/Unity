﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jump : MonoBehaviour
{
    public Rigidbody jumpp;
    public float jumpPower;
    public float max = 15;
    public float min = 5;
    public float speed = 0;
    public bool isjunp = true;

    // Use this for initialization
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {

        if (isjunp)
        {
            #region    
            if (Input.GetKey(KeyCode.Space))
            {
                jumpPower += Time.deltaTime * min;
                if (jumpPower >= max)
                {
                    jumpPower = max;
                }


            }
            if (Input.GetKeyUp(KeyCode.Space))
            {

                jumpp.velocity = new Vector3(speed, jumpPower, 0f);
                jumpPower = min;
            }

            if (Input.GetKey(KeyCode.LeftArrow))
            {
                speed = 2;

            }
            if (Input.GetKeyUp(KeyCode.LeftArrow))
            {

                speed = 0;
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                speed = -2;

            }
            if (Input.GetKeyUp(KeyCode.RightArrow))
            {
                speed = 0;

            }
            #endregion
        }



    }
    void OnCollisionEnter(Collision other)
    {
       
        if (other.transform.tag == null)
        {
            isjunp = false;
        }
        

        if (other.transform.tag == "qiang")
        {
            Debug.Log("tan");
        }
       
    }
}
   