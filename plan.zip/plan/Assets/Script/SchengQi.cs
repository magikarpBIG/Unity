﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SchengQi : MonoBehaviour {
    public float produceTime = 0.6f;
    public GameObject EEnm;

    private float Pos=0;
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        Pos = Random.Range(0,6);
        produceTime -= Time.deltaTime;
        if (produceTime < 0)
        {
            Instantiate(EEnm, new Vector3(this.transform.position.x+Pos,this.transform.position.y,this.transform.position.z), this.transform.rotation);
            produceTime = 0.6f;
        }

        
	}
}
