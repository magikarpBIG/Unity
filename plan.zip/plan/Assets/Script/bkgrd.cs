﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bkgrd : MonoBehaviour {

    public float dist=1;



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.Translate(new Vector3(0,-dist*Time.deltaTime*0.2f,0));
        if(this.transform.position.y<-10)
        {
            this.transform.position=new Vector3(0,9,0);
        }
	}
}
