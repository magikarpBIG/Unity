﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour {
    public float speed = 5;
    public Transform m_rocket;
    public float lifep = 6;
    public float m_rocketrate;
    public Transform m_transform;

    // Use this for initialization
    void Start () {
        m_transform = this.transform;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.A))
        {
            
            if (Input.GetMouseButtonDown(0) || Input.GetKey(KeyCode.Space))
            {
                speed = 2;

            }
            else {
                speed = 5;
            }
            this.transform.Translate(new Vector3(speed*Time.deltaTime,0,0));
        }
        if (Input.GetKey(KeyCode.D))
        {
            
            if (Input.GetMouseButtonDown(0) || Input.GetKey(KeyCode.Space))
            {
                speed = 2;

            }
            else
            {
                speed = 5;
            }
            this.transform.Translate(new Vector3(speed * Time.deltaTime*-1, 0, 0));
        }
        if (Input.GetKey(KeyCode.W))
        {
           
            if (Input.GetMouseButtonDown(0) || Input.GetKey(KeyCode.Space))
            {
                speed = 2;

            }
            else
            {
                speed = 5;
            } 
            this.transform.Translate(new Vector3(0, 0, speed * Time.deltaTime*-1));
        }
        if (Input.GetKey(KeyCode.S))
        { 
            if (Input.GetMouseButtonDown(0) || Input.GetKey(KeyCode.Space))
            {
                speed = 2;

            }else
            {
                speed = 5;
            }
            this.transform.Translate(new Vector3(0, 0,speed * Time.deltaTime));
           
            
        }
        m_rocketrate -= Time.deltaTime;
        if (m_rocketrate <= 0)
        {
            m_rocketrate = 0.1f;

            if (Input.GetKey(KeyCode.Space) || Input.GetMouseButton(0))
            {
                Instantiate(m_rocket, m_transform.position, m_rocket.rotation);
            }
        }

    }

    void OnTriggerEnter(Collider other)
    {
        //if (other.tag.CompareTo("Ezidan") != 0)
        //{
        //    lifep -= 1;
        //    if (lifep <= 0)
        //    {
        //        Destroy(this.gameObject);
        //    }
        //}
        if (other.transform.tag !="zidan")
        {
               lifep -= 1;
               if (lifep <= 0)
               {
                   Destroy(this.gameObject);
               }
        }
    }
}
