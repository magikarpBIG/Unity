﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rocketFly : MonoBehaviour {
    public float flySpeed=10;
    public float power = 1;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.Translate(new Vector3(0,flySpeed * Time.deltaTime ,0));
	}
    void OnTriggerEnter(Collider other)
    {
        //if (other.tag.CompareTo("Enemy") != 0)
        //{
        //    return;
        //   Destroy(this.gameObject);
        //}
        if (other.transform.tag == "Enemy")
        {
            
            Destroy(this.gameObject);
        }
    }
}
