﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyMove : MonoBehaviour {

    public int m_point = 10;
    public float enemySpeed=4;
    public float m_life=10;
  
    public float timeEnemy = 1.2f; 
    public GameObject enemyRocket;
    // Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.Translate(new Vector3(0,enemySpeed*Time.deltaTime*-1,0),Space.Self);
        //this.transform.rotation = Quaternion.Euler(0, 0, 45);
            // this.transform.Rotate(0,0,enemySpeed*Time.deltaTime*5f);
        


        timeEnemy -= Time.deltaTime;
        if (timeEnemy < 0)
        {
            Instantiate(enemyRocket, new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z - 0.72f), enemyRocket.transform.rotation);
            timeEnemy = 1.2f;
        }

        
	}
    void OnTriggerEnter(Collider other)
    {
        if (other.tag.CompareTo("zidan") == 0)
        {
           rocketFly rocket = other.GetComponent<rocketFly>();
            if (rocket != null)
            {
                m_life -= rocket.power;

                if (m_life <= 0)
                {
                    gameManager.instance.Addscore(m_point);
                    Destroy(this.gameObject);
                }

            }
        }
        else if (other.tag.CompareTo("player")==0)
        {
            m_life = 0;
            Destroy(this.gameObject);
            
        }

       
    }
}
